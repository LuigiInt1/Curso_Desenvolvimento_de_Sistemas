public enum Identefication {
    HUMAN, SATELLITE, SENSOR
}
