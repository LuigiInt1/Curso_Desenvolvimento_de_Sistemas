public enum Intensity {
    HIGH, MEDIUM, LOW
}
