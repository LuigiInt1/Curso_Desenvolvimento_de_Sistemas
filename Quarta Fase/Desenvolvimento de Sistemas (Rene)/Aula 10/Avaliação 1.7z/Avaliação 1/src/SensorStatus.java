public enum SensorStatus {
    OPERATIONAL, DEAD
}
