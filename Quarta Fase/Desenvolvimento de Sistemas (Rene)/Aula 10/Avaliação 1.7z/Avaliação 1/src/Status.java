public enum Status {
    ACTIVE, CONTROLLED, EXTINCT
}
